#ifndef _FTS_SYSCALL_H_
#define _FTS_SYSCALL_H_
#include<linux/linkage.h>
asmlinkage long sys_fts_syscall(char*,int);
#endif